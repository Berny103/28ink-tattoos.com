/* ================================================================
   28ink-tattoos MARRAKECH — main.js v4
   ================================================================ */
'use strict';

document.addEventListener('DOMContentLoaded', () => {
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  // components.js injects shared navigation on DOMContentLoaded just before this handler.
  window.i18n?.applyTranslations();

  /* ── Loader ─────────────────────────────────────────────── */
  window.addEventListener('load', () => {
    setTimeout(() => {
      const l = document.getElementById('loader');
      if (l) l.classList.add('hidden');
    }, 600);
  });

  /* ── Navbar scroll ──────────────────────────────────────── */
  const nav = document.getElementById('nav');
  if (nav) {
    const onScroll = () => nav.classList.toggle('stuck', window.scrollY > 40);
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
    // Active link
    const page = location.pathname.split('/').pop() || 'index.html';
    nav.querySelectorAll('.nav-links a').forEach(a => {
      if (a.getAttribute('href') === page) a.classList.add('active');
    });
    nav.querySelectorAll('.nav-drawer a').forEach(a => {
      if (a.getAttribute('href') === page) a.classList.add('active');
    });
  }

  /* ── Mobile Drawer ──────────────────────────────────────── */
  const burger = document.getElementById('navBurger');
  const drawer = document.getElementById('navDrawer');
  if (burger && drawer) {
    const openMenu = () => {
      drawer.classList.add('open');
      burger.classList.add('open');
      burger.setAttribute('aria-expanded', 'true');
      document.body.style.overflow = 'hidden';
      window.i18n?.applyTranslations();
    };
    const closeMenu = () => {
      drawer.classList.remove('open');
      burger.classList.remove('open');
      burger.setAttribute('aria-expanded', 'false');
      document.body.style.overflow = '';
      window.i18n?.applyTranslations();
    };
    burger.addEventListener('click', () =>
      drawer.classList.contains('open') ? closeMenu() : openMenu()
    );
    drawer.querySelectorAll('a').forEach(a => a.addEventListener('click', closeMenu));
    drawer.querySelector('.drawer-close')?.addEventListener('click', closeMenu);
    drawer.addEventListener('click', e => { if (e.target === drawer) closeMenu(); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape') closeMenu(); });
  }

  /* ── Hero Slider ────────────────────────────────────────── */
  const slides = document.querySelectorAll('.hero-slide');
  const dots = document.querySelectorAll('.hero-dot');
  const counterEl = document.getElementById('heroCurrentSlide');
  let current = 0;
  let heroTimer = null;

  const goTo = (idx) => {
    slides[current]?.classList.remove('on');
    dots[current]?.classList.remove('on');
    dots[current]?.setAttribute('aria-selected', 'false');

    // Pause prev video
    const prevVid = slides[current]?.querySelector('video');
    if (prevVid) { prevVid.pause(); prevVid.currentTime = 0; }

    current = (idx + slides.length) % slides.length;

    slides[current]?.classList.add('on');
    dots[current]?.classList.add('on');
    dots[current]?.setAttribute('aria-selected', 'true');

    // Play current video
    const vid = slides[current]?.querySelector('video');
    if (vid) {
      vid.currentTime = 0;
      vid.play().catch(() => {});
    }

    if (counterEl) {
      counterEl.textContent = String(current + 1).padStart(2, '0');
    }
  };

  const startTimer = () => {
    stopTimer();
    heroTimer = setInterval(() => goTo(current + 1), 6000);
  };
  const stopTimer = () => { if (heroTimer) clearInterval(heroTimer); };

  if (slides.length > 0) {
    dots.forEach((dot, i) => {
      dot.addEventListener('click', () => { goTo(i); startTimer(); });
    });

    // Touch swipe
    let tx = 0;
    const hero = document.getElementById('hero');
    if (hero) {
      hero.addEventListener('touchstart', e => { tx = e.touches[0].clientX; }, { passive: true });
      hero.addEventListener('touchend', e => {
        const dx = e.changedTouches[0].clientX - tx;
        if (Math.abs(dx) > 50) { goTo(dx < 0 ? current + 1 : current - 1); startTimer(); }
      }, { passive: true });
    }
    if (!reducedMotion) startTimer();
  }

  /* ── Reel Carousel ──────────────────────────────────────── */
  const track = document.getElementById('reelTrack');
  if (track) {
    const items = track.querySelectorAll('.reel-item');
    let reelPos = 0;
    const itemW = () => (items[0]?.offsetWidth || 200) + 6;
    const maxPos = () => Math.max(0, items.length * itemW() - track.parentElement.offsetWidth);

    const slide = (dir) => {
      reelPos = Math.max(0, Math.min(reelPos + dir * itemW() * 2, maxPos()));
      track.style.transform = `translateX(-${reelPos}px)`;
    };

    document.querySelectorAll('.reel-btn.prev').forEach(b => b.addEventListener('click', () => slide(-1)));
    document.querySelectorAll('.reel-btn.next').forEach(b => b.addEventListener('click', () => slide(1)));

    // Touch drag
    let startX = 0, startPos = 0;
    track.addEventListener('touchstart', e => {
      startX = e.touches[0].clientX;
      startPos = reelPos;
    }, { passive: true });
    track.addEventListener('touchmove', e => {
      const dx = startX - e.touches[0].clientX;
      reelPos = Math.max(0, Math.min(startPos + dx, maxPos()));
      track.style.transform = `translateX(-${reelPos}px)`;
    }, { passive: true });

    // Hover play/pause
    items.forEach(item => {
      const vid = item.querySelector('video');
      if (!vid) return;
      item.addEventListener('mouseenter', () => vid.play().catch(() => {}));
      item.addEventListener('mouseleave', () => { vid.pause(); vid.currentTime = 0; });
    });
  }

  /* ── Gallery Filter ─────────────────────────────────────── */
  const filters = document.querySelectorAll('.gal-filter');
  const galItems = document.querySelectorAll('.gal-item');
  if (filters.length && galItems.length) {
    filters.forEach(btn => {
      btn.addEventListener('click', () => {
        filters.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const cat = btn.dataset.cat;
        galItems.forEach(item => {
          const cats = (item.dataset.cat || '').split(' ');
          const show = cat === 'all' || cats.includes(cat);
          item.style.opacity = show ? '1' : '0';
          item.style.pointerEvents = show ? '' : 'none';
          item.setAttribute('aria-hidden', show ? 'false' : 'true');
          item.classList.toggle('filtered-out', !show);
          item.setAttribute('aria-hidden', show ? 'false' : 'true');
          item.classList.toggle('filtered-out', !show);
        });
      });
    });
  }

  /* ── FAQ Accordion ──────────────────────────────────────── */
  document.querySelectorAll('.faq-q').forEach(btn => {
    btn.addEventListener('click', () => {
      const item = btn.closest('.faq-item');
      const isOpen = item.classList.contains('open');
      // Close all in same list
      btn.closest('.faq-list')?.querySelectorAll('.faq-item.open').forEach(o => {
        o.classList.remove('open');
        o.querySelector('.faq-q')?.setAttribute('aria-expanded', 'false');
      });
      if (!isOpen) {
        item.classList.add('open');
        btn.setAttribute('aria-expanded', 'true');
      }
    });
  });


  /* ── User-controlled playback for gallery, reels and page media ── */
  document.querySelectorAll('video').forEach(video => {
    if (video.closest('.hero-slide, .page-hero-bg')) return;
    video.controls = true;
    video.setAttribute('controlsList', 'nodownload');
    video.setAttribute('preload', 'metadata');
    video.classList.add('video-playable');
    video.addEventListener('click', () => {
      if (video.paused) video.play().catch(() => {});
      else video.pause();
    });
  });
  /* ── Responsive, viewport-aware background video playback ── */
  const backgroundVideos = document.querySelectorAll('video[autoplay]');
  if (backgroundVideos.length && 'IntersectionObserver' in window) {
    const videoObserver = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        const video = entry.target;
        if (entry.isIntersecting && !reducedMotion && !document.hidden) video.play().catch(() => {});
        else video.pause();
      });
    }, { rootMargin: '160px 0px', threshold: 0.05 });
    backgroundVideos.forEach(video => videoObserver.observe(video));
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) backgroundVideos.forEach(video => video.pause());
    });
  }

  /* ── Scroll Reveal ──────────────────────────────────────── */
  const revealObs = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.classList.add('vis');
        revealObs.unobserve(e.target);
      }
    });
  }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });

  document.querySelectorAll('[data-r]').forEach(el => revealObs.observe(el));

  /* ── Count-up ───────────────────────────────────────────── */
  const countObs = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (!e.isIntersecting) return;
      const el = e.target;
      const target = parseInt(el.dataset.count, 10);
      const sup = el.querySelector('sup')?.outerHTML || '';
      let start = 0;
      const step = target / 60;
      const tick = () => {
        start = Math.min(start + step, target);
        el.innerHTML = Math.round(start) + sup;
        if (start < target) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
      countObs.unobserve(el);
    });
  }, { threshold: 0.5 });

  document.querySelectorAll('[data-count]').forEach(el => countObs.observe(el));

  /* ── Chatbot ────────────────────────────────────────────── */
  const cbToggle = document.getElementById('cb-toggle');
  const cbWindow = document.getElementById('cb-window');
  const cbClose  = cbWindow?.querySelector('.cb-close');
  const cbMsgs   = document.getElementById('chatbotMessages');
  const cbInput  = document.getElementById('chatbotInput');
  const cbSend   = document.getElementById('chatbotSend');

  const replies = {
    fr: {
      welcome: "Bonjour ! Je suis l'assistant 28ink-tattoos. Comment puis-je vous aider ?",
      price:   "Pour parler de votre idée, écrivez au studio sur WhatsApp avec le motif et l’emplacement souhaité.",
      book:    "Pour parler des disponibilités, contactez le studio sur WhatsApp au +212 069 372 1314.",
      hygiene: "Pour toute question sur le matériel et l’hygiène, contactez directement le studio.",
      location:"Le studio est indiqué à 40100 Marrakech. Retrouvez le repère précis et l’itinéraire dans la page Contact.",
      default: "Bonne question ! Pour une réponse précise, écrivez-nous sur WhatsApp : +212 069 372 1314",
    },
    en: {
      welcome: "Hello! I'm the 28ink-tattoos assistant. How can I help you?",
      price:   "Pour parler de votre idée, écrivez au studio sur WhatsApp avec le motif et l’emplacement souhaité.",
      book:    "To discuss availability, contact the studio on WhatsApp at +212 069 372 1314.",
      hygiene: "For questions about equipment and hygiene, contact the studio directly.",
      location:"The studio is listed in 40100 Marrakech. Find the supplied map pin and directions on the Contact page.",
      default: "Good question! For a precise answer, WhatsApp us: +212 069 372 1314",
    },
    it: {
      welcome: "Ciao! Sono l'assistente 28ink-tattoos. Come posso aiutarti?",
      price:   "Per parlare della tua idea, scrivi allo studio su WhatsApp indicando il motivo e la posizione desiderata.",
      book:    "Per conoscere le disponibilità, contatta lo studio su WhatsApp al +212 069 372 1314.",
      hygiene: "Per domande su materiali e igiene, contatta direttamente lo studio.",
      location:"Lo studio è indicato a 40100 Marrakech. Trovi la posizione condivisa e l'itinerario nella pagina Contatti.",
      default: "Ottima domanda! Per una risposta precisa, scrivici su WhatsApp: +212 069 372 1314",
    },
  };

  window.addChatMessage = window.addChatMessage || function(text, who) {
    if (!cbMsgs) return;
    const d = document.createElement('div');
    d.className = 'cb-msg ' + (who || 'bot');
    d.textContent = text;
    cbMsgs.appendChild(d);
    cbMsgs.scrollTop = cbMsgs.scrollHeight;
  };

  const getLang = () => (window.i18n?.currentLang?.() || 'fr');

  if (cbToggle && cbWindow) {
    cbToggle.addEventListener('click', () => {
      const open = cbWindow.classList.toggle('open');
      if (open && cbMsgs && cbMsgs.children.length === 0) {
        const lang = getLang();
        setTimeout(() => window.addChatMessage(replies[lang]?.welcome || replies.fr.welcome, 'bot'), 300);
      }
    });
    cbClose?.addEventListener('click', () => cbWindow.classList.remove('open'));
  }

  const sendMsg = () => {
    if (!cbInput) return;
    const txt = cbInput.value.trim();
    if (!txt) return;
    window.addChatMessage(txt, 'user');
    cbInput.value = '';
    const lang = getLang();
    const r = replies[lang] || replies.fr;
    const lower = txt.toLowerCase();
    let reply = r.default;
    if (/prix|tarif|coût|cost|price|quanto|prezzo/.test(lower)) reply = r.price;
    else if (/réserv|book|prendr|appoint|prenotare/.test(lower)) reply = r.book;
    else if (/hygièn|steril|propre|clean|safe|sicur/.test(lower)) reply = r.hygiene;
    else if (/adress|où|where|location|dove|médina/.test(lower)) reply = r.location;
    setTimeout(() => {
      window.addChatMessage(reply, 'bot');
      if (/réserv|book|prix|tarif|price/.test(lower)) {
        setTimeout(() => window.addChatMessage('👉 wa.me/212693721314', 'bot'), 800);
      }
    }, 500);
  };

  cbSend?.addEventListener('click', sendMsg);
  cbInput?.addEventListener('keydown', e => { if (e.key === 'Enter') sendMsg(); });

  document.querySelectorAll('.cb-q-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const lang = getLang();
      const r = replies[lang] || replies.fr;
      window.addChatMessage(btn.textContent, 'user');
      setTimeout(() => window.addChatMessage(r[btn.dataset.topic] || r.default, 'bot'), 400);
    });
  });

  /* ── Lightbox ───────────────────────────────────────────── */
  const lb = document.getElementById('lightbox');
  const lbContent = lb?.querySelector('.lb-content');
  let lbItems = [];
  let lbIdx = 0;

  const openLb = (idx) => {
    lbIdx = idx;
    const src = lbItems[lbIdx];
    if (!lbContent || !src) return;
    lbContent.innerHTML = '';
    if (/\.(mp4|webm|ogg)$/i.test(src)) {
      const v = document.createElement('video');
      v.src = src; v.controls = true; v.autoplay = true;
      lbContent.appendChild(v);
    } else {
      const img = document.createElement('img');
      img.src = src; img.alt = 'Tatouage 28ink-tattoos';
      lbContent.appendChild(img);
    }
    lb.classList.add('open');
    document.body.style.overflow = 'hidden';
  };
  const closeLb = () => {
    lb?.classList.remove('open');
    document.body.style.overflow = '';
    if (lbContent) lbContent.innerHTML = '';
  };

  if (lb) {
    document.querySelectorAll('.gal-item').forEach((item, i) => {
      const src = item.querySelector('video')?.src || item.querySelector('img')?.src || '';
      lbItems.push(src);
      item.addEventListener('click', () => openLb(i));
    });
    lb.querySelector('.lb-close')?.addEventListener('click', closeLb);
    lb.querySelector('.lb-prev')?.addEventListener('click', () => openLb((lbIdx - 1 + lbItems.length) % lbItems.length));
    lb.querySelector('.lb-next')?.addEventListener('click', () => openLb((lbIdx + 1) % lbItems.length));
    lb.addEventListener('click', e => { if (e.target === lb) closeLb(); });
    document.addEventListener('keydown', e => {
      if (!lb.classList.contains('open')) return;
      if (e.key === 'Escape') closeLb();
      if (e.key === 'ArrowLeft') openLb((lbIdx - 1 + lbItems.length) % lbItems.length);
      if (e.key === 'ArrowRight') openLb((lbIdx + 1) % lbItems.length);
    });
  }

  /* ── Contact Form → WhatsApp ────────────────────────────── */
  const form = document.getElementById('contactForm');
  if (form) {
    form.addEventListener('submit', e => {
      e.preventDefault();
      const name    = form.querySelector('[name="name"]')?.value.trim() || '';
      const style   = form.querySelector('[name="style"]')?.value || '';
      const message = form.querySelector('[name="message"]')?.value.trim() || '';
      const phone   = form.querySelector('[name="phone"]')?.value.trim() || '';
      const email   = form.querySelector('[name="email"]')?.value.trim() || '';
      const msg = `Bonjour 28ink-tattoos !\n\nNom : ${name}\nTél : ${phone || 'N/A'}\nEmail : ${email || 'N/A'}\nStyle : ${style || 'N/A'}\n\nProjet :\n${message}`;
      window.open('https://wa.me/212693721314?text=' + encodeURIComponent(msg), '_blank', 'noopener,noreferrer');
    });
  }

}); // end DOMContentLoaded
