/* ================================================================
   28ink-tattoos — Shared Components v4
   ================================================================ */
'use strict';

const NAV_HTML = `
<div id="loader" aria-hidden="true">
  <img id="loader-logo" src="/assets/964ea163-e7f9-4dc4-839b-a2d78b7dc0b6_d15cf292.jpeg" alt="28INK" width="52" height="52">
  <div class="loader-bar-wrap"><div class="loader-bar-fill"></div></div>
  <span class="loader-label">28ink-tattoos Marrakech</span>
</div>

<nav id="nav" role="navigation" aria-label="Navigation principale">
  <a href="index.html" class="nav-logo" aria-label="28ink-tattoos Marrakech — Accueil">
    <img class="nav-logo-mark" src="/assets/964ea163-e7f9-4dc4-839b-a2d78b7dc0b6_d15cf292.jpeg" alt="Logo 28INK" width="42" height="42" loading="eager">
    <div class="nav-logo-text">
      <span class="nav-logo-name">28ink-tattoos</span>
    </div>
  </a>

  <div class="nav-links" role="menubar">
    <a href="index.html"        data-i18n="nav_home"     role="menuitem">Accueil</a>
    <a href="services.html"     data-i18n="nav_services"  role="menuitem">Services</a>
    <a href="realisations.html" data-i18n="nav_gallery"   role="menuitem">Réalisations</a>
    <a href="about.html"        data-i18n="nav_about"     role="menuitem">À Propos</a>
    <a href="blog.html"         data-i18n="nav_blog"      role="menuitem">Blog</a>
    <a href="faq.html"          data-i18n="nav_faq"       role="menuitem">FAQ</a>
    <a href="contact.html"      data-i18n="nav_contact"   role="menuitem">Contact</a>
  </div>

  <div class="nav-social" aria-label="Réseaux sociaux">
  <a href="https://wa.me/212693721314" target="_blank" rel="noopener noreferrer" aria-label="WhatsApp" title="WhatsApp"><svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/><path d="M12 0C5.373 0 0 5.373 0 12c0 2.099.548 4.07 1.504 5.783L0 24l6.395-1.682A11.936 11.936 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 21.818a9.818 9.818 0 01-5.003-1.366l-.358-.213-3.79.997.987-3.656-.234-.374A9.818 9.818 0 1112 21.818z"/></svg></a>
  <a href="https://www.instagram.com/28ink_tattoos?stkn=MXU4OHk4Yms0cm4zaQ==" target="_blank" rel="noopener noreferrer" aria-label="Instagram" title="Instagram"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" aria-hidden="true"><rect x="2" y="2" width="20" height="20" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/></svg></a>
  <a href="https://www.tiktok.com/@28ink.tattoos?_r=1&_t=ZS-9A07bAeZGae" target="_blank" rel="noopener noreferrer" aria-label="TikTok" title="TikTok"><svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-2.88 2.5 2.89 2.89 0 01-2.89-2.89 2.89 2.89 0 012.89-2.89c.28 0 .54.04.79.1V9.01a6.27 6.27 0 00-.79-.05 6.34 6.34 0 00-6.34 6.34 6.34 0 006.34 6.34 6.34 6.34 0 006.33-6.34V8.86a8.17 8.17 0 004.78 1.53V6.93a4.85 4.85 0 01-1.01-.24z"/></svg></a>
</div>
    <div class="nav-right">
    <div class="lang-sw" role="group" aria-label="Langue">
      <button class="lang-btn active" data-lang="fr" aria-pressed="true">FR</button>
      <button class="lang-btn" data-lang="en" aria-pressed="false">EN</button>
      <button class="lang-btn" data-lang="it" aria-pressed="false">IT</button>
    </div>
    <a href="contact.html" class="nav-cta" data-i18n="nav_book">Prendre RDV</a>
    <button class="nav-burger" id="navBurger"
            aria-label="Ouvrir le menu" aria-expanded="false" aria-controls="navDrawer">
      <span></span><span></span><span></span>
    </button>
  </div>
</nav>

<div class="nav-drawer" id="navDrawer" role="dialog" aria-modal="true" aria-label="Menu mobile">
  <button class="drawer-close" type="button" aria-label="Fermer le menu">×</button>
  <a href="index.html"        data-i18n="nav_home">Accueil</a>
  <a href="services.html"     data-i18n="nav_services">Services</a>
  <a href="realisations.html" data-i18n="nav_gallery">Réalisations</a>
  <a href="about.html"        data-i18n="nav_about">À Propos</a>
  <a href="blog.html"         data-i18n="nav_blog">Blog</a>
  <a href="faq.html"          data-i18n="nav_faq">FAQ</a>
  <a href="contact.html"      data-i18n="nav_contact">Contact</a>
  <div class="drawer-sep"></div>
  <a href="contact.html" class="drawer-book" data-i18n="nav_book">Prendre RDV</a>
  <div class="drawer-lang">
    <button class="lang-btn" data-lang="fr">FR</button>
    <button class="lang-btn" data-lang="en">EN</button>
    <button class="lang-btn" data-lang="it">IT</button>
  </div>
</div>`;

const FOOTER_HTML = `
<footer id="footer" role="contentinfo">
  <div class="footer-compact">
    <div class="footer-compact-brand">
      <img class="footer-logo-mark" src="/assets/964ea163-e7f9-4dc4-839b-a2d78b7dc0b6_d15cf292.jpeg" alt="Logo 28INK" width="42" height="42" loading="lazy">
      <div>
        <p class="footer-brand-name">28ink-tattoos</p>
        <p class="footer-brand-tag" data-i18n="footer_tagline">Studio de tatouage et créations personnalisées à Marrakech, Maroc.</p>
      </div>
    </div>
    <div class="footer-compact-contact">
      <a href="https://wa.me/212693721314" target="_blank" rel="noopener noreferrer">WhatsApp · +212 069 372 1314</a>
      <a href="mailto:amourkira216@gmail.com">amourkira216@gmail.com</a>
    </div>
    <div class="footer-social" aria-label="Réseaux sociaux">
      <a href="https://www.instagram.com/28ink_tattoos?stkn=MXU4OHk4Yms0cm4zaQ==" target="_blank" rel="noopener noreferrer" aria-label="Instagram"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><rect x="2" y="2" width="20" height="20" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/></svg></a>
      <a href="https://wa.me/212693721314" target="_blank" rel="noopener noreferrer" aria-label="WhatsApp"><svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/><path d="M12 0C5.373 0 0 5.373 0 12c0 2.099.548 4.07 1.504 5.783L0 24l6.395-1.682A11.936 11.936 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 21.818a9.818 9.818 0 01-5.003-1.366l-.358-.213-3.79.997.987-3.656-.234-.374A9.818 9.818 0 1112 21.818z"/></svg></a>
      <a href="https://www.tiktok.com/@28ink.tattoos?_r=1&_t=ZS-9A07bAeZGae" target="_blank" rel="noopener noreferrer" aria-label="TikTok"><svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-2.88 2.5 2.89 2.89 0 01-2.89-2.89 2.89 2.89 0 012.89-2.89c.28 0 .54.04.79.1V9.01a6.27 6.27 0 00-.79-.05 6.34 6.34 0 00-6.34 6.34 6.34 0 006.34 6.34 6.34 6.34 0 006.33-6.34V8.86a8.17 8.17 0 004.78 1.53V6.93a4.85 4.85 0 01-1.01-.24z"/></svg></a>
    </div>
  </div>
  <div class="footer-bottom"><p class="footer-copy" data-i18n="footer_copy">© 2026 28ink-tattoos Marrakech. Tous droits réservés.</p><nav class="footer-legal" aria-label="Liens utiles"><a href="faq.html">FAQ</a><a href="contact.html">Contact</a></nav></div>
</footer>`;
const CHATBOT_HTML = `
<button id="cb-toggle" aria-label="Ouvrir le chat 28ink-tattoos">
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
    <path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/>
  </svg>
</button>

<div id="cb-window" role="dialog" aria-label="Chat 28ink-tattoos" aria-modal="true">
  <div class="cb-head">
    <div class="cb-av" aria-hidden="true">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="4"/><path d="M6 20v-2a4 4 0 014-4h4a4 4 0 014 4v2"/></svg>
    </div>
    <div class="cb-head-info">
      <h4 data-i18n="chatbot_name">28ink-tattoos Assistant</h4>
      <p><span class="cb-dot" aria-hidden="true"></span><span data-i18n="chatbot_status">En ligne</span></p>
    </div>
    <button class="cb-close" aria-label="Fermer le chat">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
    </button>
  </div>
  <div class="cb-msgs" id="chatbotMessages" role="log" aria-live="polite"></div>
  <div class="cb-quick" role="group" aria-label="Questions rapides">
    <button class="cb-q-btn" data-topic="price"    data-i18n="chatbot_quick_price">💰 Tarifs</button>
    <button class="cb-q-btn" data-topic="book"     data-i18n="chatbot_quick_book">📅 Réserver</button>
    <button class="cb-q-btn" data-topic="hygiene"  data-i18n="chatbot_quick_hygiene">🧼 Hygiène</button>
    <button class="cb-q-btn" data-topic="location" data-i18n="chatbot_quick_location">📍 Adresse</button>
  </div>
  <div class="cb-form">
    <input type="text" id="chatbotInput" class="cb-input"
           data-i18n-placeholder="chatbot_placeholder" placeholder="Votre question..."
           aria-label="Votre message" autocomplete="off">
    <button id="chatbotSend" class="cb-send" aria-label="Envoyer">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
    </button>
  </div>
</div>`;

const LIGHTBOX_HTML = `
<div id="lightbox" role="dialog" aria-modal="true" aria-label="Visionneuse d'images">
  <button class="lb-close" aria-label="Fermer">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
  </button>
  <button class="lb-prev" aria-label="Précédent">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><polyline points="15 18 9 12 15 6"/></svg>
  </button>
  <div class="lb-content"></div>
  <button class="lb-next" aria-label="Suivant">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><polyline points="9 18 15 12 9 6"/></svg>
  </button>
</div>`;

document.addEventListener('DOMContentLoaded', () => {
  document.body.insertAdjacentHTML('afterbegin', NAV_HTML);
  document.body.insertAdjacentHTML('beforeend', FOOTER_HTML + CHATBOT_HTML + LIGHTBOX_HTML);
});
