# Déploiement Vercel — 28ink-tattoos

Le site est un site **statique HTML/CSS/JavaScript** : aucun serveur applicatif ni étape de compilation ne sont nécessaires.

## Déployer depuis Git
1. Importez ce dossier dans un dépôt Git, puis reliez ce dépôt à un projet Vercel.
2. Choisissez **Other** comme framework si Vercel demande un préréglage.
3. Laissez *Build Command* vide et indiquez `.` comme *Output Directory* (la racine où se trouvent `index.html`, `assets/` et `css/`).
4. Lancez le déploiement. La configuration `vercel.json` est déjà incluse.

## Déployer avec le CLI
Après connexion à votre compte Vercel dans un terminal : `vercel --prod`.

Les versions localisées complètes sont générées dans `/en/` et `/it/`. Le ZIP inclut également les médias optimisés, le sitemap et les consignes de déploiement.
